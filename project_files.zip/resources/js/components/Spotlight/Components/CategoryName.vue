<template>
    <b class="mb-1.5 block text-xs text-gray-500">
        <slot />
    </b>
</template>
<script>
export default {
    name: 'CategoryName',
}
</script>
