<template>
    <svg
        class="preview-list-icon"
        fill="none"
        stroke="currentColor"
        stroke-width="1.5"
        fill-rule="evenodd"
        stroke-linecap="round"
        stroke-linejoin="round"
        width="15px"
        height="15px"
        viewBox="0 0 17 12"
        version="1.1"
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
    >
        <path
            d="M14.2729998,10.7729998 C15.6774712,10.0073227 16.384111,8.38688297 15.9895447,6.83668332 C15.5949785,5.28648367 14.1996249,4.20105605 12.5999998,4.19999993 L11.7179998,4.19999993 C11.1377566,1.9556703 9.23470173,0.300843012 6.93154234,0.0378706728 C4.62838295,-0.225101666 2.40127934,0.958148431 1.33005562,3.01391529 C0.258831904,5.06968215 0.564955244,7.57295196 2.09999996,9.30999984"
            id="Path"
        ></path>
        <line x1="8.5" y1="7" x2="8.5" y2="12" id="Path"></line>
        <line x1="6" y1="9.5" x2="11" y2="9.5" id="Path"></line>
    </svg>
</template>

<script>
export default {
    name: 'CloudPlusIcon',
}
</script>

<style lang="scss">
.preview-list-icon {
    path,
    line {
        color: inherit;
    }
}
</style>
